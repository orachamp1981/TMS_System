<?php 

	class humanlife
{
   public $age;
	
public function getage($age){

	$this->age = $age;
	return $age;
	}
}

$age = new humanlife();
echo "this age  ".$age->getage(30);
 ?>