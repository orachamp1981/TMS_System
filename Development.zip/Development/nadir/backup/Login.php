<?php
   if (isset($_POST['submit'])) {

   	/*{  
    echo "Your firstname is " . $_POST['u'] == 'nadir' . "<br>";

    echo "You password is " . $_POST['p'] == 'nadir';

   }  else {

    echo "Your form is not submitted yet please fill the form and visit again";
  }*/


if ($_POST['u'] == 'nadir') {

$msg ='Welcome back, friend!!!<br/>';

echo $msg;
echo $msg;

}
else {

echo "You're not a member of this site";

}

}
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="css/style1.css">
</head>
<body>
<div class="login">
	<h1>Login</h1>
    <form method="POST">
    	<input type="text" name="u" placeholder="Username" required="required" />
        <input type="password" name="p" placeholder="Password" required="required" />
        <button type="submit" class="btn btn-primary btn-block btn-large" >Let me in.
        <!--a href='http://localhost/nadir/dashboard.php'></a> formaction="/nadir/dashboard.php"-->
                
        </button>
        
    </form>
</div>
</body>
</html>