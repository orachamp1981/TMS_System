<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="E:/nadir/css/styles.css">
</head>

<body>

<?php

try {
    $conn = new PDO('oci:dbname=172.28.1.32/drpluto', 'erp', 'erp1');
} 
catch (PDOException $e) {
    //echo 'Connection failed: ' . $e->getMessage();
    exit;
}

$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

$ergebnis = 0;

// $a and $b must be the PHP data values
//$a = 100;
$a = 'Nadir Ali';
$b = 1;

$date = '17-JAN-2017';

// Remove quotes around :var_datum
$stmt = $conn->prepare("CALL mytst(:var_kunde,:ergebnis)");
$stmt->bindParam(':var_kunde',$a,PDO::PARAM_INT);
//$stmt->bindParam(':var_rabatt',$b,PDO::PARAM_INT);
//$stmt->bindParam(':var_datum',$date,PDO::PARAM_STR,10);
// Set a length for the outbind
$stmt->bindParam(':ergebnis',$ergebnis,PDO::PARAM_INT|PDO::PARAM_INPUT_OUTPUT, 40);
//$stmt->debugDumpParams();
$stmt->execute();
"<br>\n";
"<br>\n";
echo "Output param is: $ergebnis\n";

?>
</body>
</html>