<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="E:/nadir/css/styles.css">
</head>

<body>

<?php
echo "Data Description!";
?>

<br>

<?php
$color = 'red';

echo "The color is " .$color. "<br>";
?>

<?php
//database parameter
$db_name = "drpluto";
$user = "erp";
$password = "erp1";
$sid = "DRPLUTO";
$port = "1521";
//use phpGrid\C_DataGrid;

//function of connection
//$conn = oci_connect($user, $password, "//172.28.1.32/".$db_name);
$conn = oci_connect($user, $password, "//172.28.1.32/".$db_name);
//$conn = oci_connect ($user, $password, "//localhost/".$db_name);
if (!$conn) {
    $e = oci_error();
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}

$sql = "SELECT USER_ID, USER_NAME FROM HCARD_USERS_PRIV";
$stid = oci_parse($conn, $sql);
oci_execute($stid);


while (oci_fetch($stid)) {
    echo oci_result($stid, 'USER_ID') . " is ";
    echo oci_result($stid, 'USER_NAME') . "<br>\n";
}

// Displays:
//   1000 is Roma
//   1100 is Venice

//$dg = new C_DataGrid("SELECT * FROM HCARD_USERS_PRIV", "orderNumber", "CARD_USERS_PRIV");

oci_free_statement($stid);
oci_close($conn);


$conn = oci_connect($user, $password, "//172.28.1.32/".$db_name);
$name ='NADIR';
$num  =4;
$sql_ins ="INSERT INTO TEST (SNO, S_NAME) VALUES ($num, '$name')";
$stid_ins = oci_parse($conn, $sql_ins);
oci_execute($stid_ins);

oci_free_statement($stid_ins);
oci_close($conn);

?>


</body>
</html>