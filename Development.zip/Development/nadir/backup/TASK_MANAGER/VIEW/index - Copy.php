<!DOCTYPE html>
<?php include 'Login.php';?>
<html>
<head>
<title></title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>
<h1> Task Management System</h1>
<div >
	<!--h1>Login</h1-->
    <form method="POST">
      
    	<input type="text" name="u" placeholder="Username" required="required" />
        <input type="password" name="p" placeholder="Password" required="required" />
        <br>
          <button type="submit" >Enter
        <!--a href='http://localhost/nadir/dashboard.php'></a> formaction="/nadir/dashboard.php"-->
              
        </button>
    </form>


</div>
  
</body>
</html>