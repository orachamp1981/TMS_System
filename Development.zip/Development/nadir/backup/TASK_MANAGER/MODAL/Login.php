<?php
//database parameter
$db_name = "drpluto";
$user = "erp";
$password = "erp1";
$sid = "DRPLUTO";
$port = "1521";

//function of connection
//$conn = oci_connect($user, $password, "//172.28.1.32/".$db_name);
$conn = oci_connect($user, $password, "//172.28.1.32/".$db_name);
//$conn = oci_connect ($user, $password, "//localhost/".$db_name);
if (!$conn) {
    $e = oci_error();
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}

$sql = 'SELECT USER_ID, USER_NAME FROM HCARD_USERS_PRIV';
$stid = oci_parse($conn, $sql);
oci_execute($stid);

while (oci_fetch($stid)) {
    /*echo oci_result($stid, 'USER_ID') . " is ";
    echo oci_result($stid, 'USER_NAME') . "<br>\n"
    ;
*/
}

// Displays:
//   1000 is Roma
//   1100 is Venice

oci_free_statement($stid);
oci_close($conn);

?>

