<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
  <h1>Table Data</h1>
 <div class="box-body table-responsive no-padding">
     <table class="table table-hover">
          <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Designation</th>
          </tr>
          <tr>
             

              </tr>
       </table>
    </div>
</body>
</html>