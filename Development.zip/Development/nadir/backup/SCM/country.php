<?php
 include("config.php");
 session_start();

//echo $_SESSION["username"];
 $loggenOnUser=substr(ucwords($_SESSION["username"]),0,10);
 $loggenOnRights =$_SESSION["rights"];

if (isset($_POST['submiti'])){
  if ($loggenOnRights =='Y'){
/// Define variables and initialize with empty values
$username = $password = $confirm_password = $confirm_email = "";
$username_err = $password_err = $confirm_password_err =$confirm_email = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["code"]))){
        $username_err = "Please enter a code.";
    } else{
        // Prepare a select statement
        $user =($_POST["code"]);

        $sql = "SELECT code FROM country WHERE code ='$user' LIMIT 1";
        
        if($stmt = mysqli_prepare($db, $sql)){
            // Bind variables to the prepared statement as parameters
           // mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["code"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){

                // store result 
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This code is already exists.";
                    echo '<script> alert("'.$username_err.'")</script>';

                } else{
                    $username = trim($_POST["code"]);
                }
            } else{
               // echo "Oops! Something went wrong. Please try again later.";
                $username_err = "Oops! Something went wrong. Please try again later.";
                echo '<script> alert("'.$username_err.'")</script>';

            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Validate password
    if(empty(trim($_POST["name"]))){
        $password_err = "Please enter the name.";    
          echo '<script> alert("'.$password_err.'")</script>'; 
    } else{
        $password = trim($_POST["name"]);
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err))

    {
        
        // Prepare an insert statement
        $user =($_POST["code"]);
        $pass =($_POST["name"]);
        $sql = "INSERT INTO country (code, name, date) VALUES (upper('$user'), upper('$pass'), date )";
        //$sql = "INSERT INTO users (username, password, comments) VALUES ('sapna1', 'sapna1', 'sitara')";
    

if(mysqli_query($db, $sql)){
//    echo "Records added successfully.";
      $success="New record created successfully";
      echo '<script> alert("'.$success.'")</script>';

} else{
    //echo "ERROR: Could not able to execute $sql. " . mysqli_error($db);
      $error="Record not created";
      echo '<script> alert("'.$error.'")</script>';

}
 
    }
    

}

}
else
{
     $error="You do not have rights";
     echo '<script> alert("'.$error.'")</script>';
}

}

?>

<!DOCTYPE html>
<html>
<html lang="en">
<head class>
  <title> </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/style2.css">


</head>
  <meta charset="utf-8">

	  <title> ERP User:- <?php echo $loggenOnUser; ?> </title>

<body>
    <!-- Navigation -->
    <!-- Navigation -->
<div>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Supply Chain Management</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li class="active"><a href="home.php">Home</a></li>
              <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Main<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="country.php">Country</a></li>
            <li><a href="city.php">City</a></li>
            <li><a href="#">Page 1-3</a></li>
            <li><a href="#">Page 1-4</a></li>
          </ul>
        </li>
        <li><a href="#">Page 2</a></li>
        <li><a href="#">Page 3</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <!--li><a href="#"><span class="glyphicon glyphicon-user"></span> <div id="LoggedInUser" class="fluid "><?php echo $loggenOnUser; ?> </a></li-->
        <li><a href="index.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
 </div>

<div class="login-html1">
<form class = "form" method="post">
	<h2>Enter New country</h2>
  <fieldset>
	<!--caption class=  "caption">Code:</caption> <input class= "text" type="text" name="code" size="24"><br>
	<caption class = "caption">Name:</caption> <input class= "text" type="text" name="name"  size="24"><br-->
	Code : <input style="text-transform:uppercase" class = "inputs" type="text" name="code" size="24">
	Name: <input style="text-transform:uppercase" class = "inputs" type="text" name="name"  size="24">
		  <input class="button" type="submit" name="submiti" value="Insert">
    </fieldset>
</form>
<br>
<hr>
<div>
<form class = "form" method="post">
  <h2>Search country</h2>
  <!--caption class=  "caption">Code:</caption> <input class= "text" type="text" name="code" size="24"><br>
  <caption class = "caption">Name:</caption> <input class= "text" type="text" name="name"  size="24"><br-->
  Name: <input style="text-transform:uppercase" class = "inputs" type="text" name="name"  size="24"> 
        <input class="button" type="submit" name="submits" value ="Search"> <br>
        <br>
</form>
<div>
<table style="width: 98.6%" table border='1'>
<tr style="width: 100%">
<th>Sno.</th>
<th>Code</th>
<th>Name</th>
<th>Date</th>
</tr>
</table>
</div>

<?php
if (isset($_POST['submits'])){

if($_SERVER["REQUEST_METHOD"] == "POST"){

        $name =($_POST["name"]);
        
        if(empty(trim($_POST["name"]))){
        $sql = "SELECT sno, code, name, date FROM country";
      }
      else
       {
         $sql = "SELECT sno, code, name, date FROM country where name = '$name'";
       } 
        $result = mysqli_query($db,$sql);

echo '<div class="tableBodyScroll" border>';
echo "<table table border='1'>";

while($row = mysqli_fetch_array($result))
{
echo "<tr style='background-color:white'>";
echo "<td>" . $row['sno'] . "</td>";
echo "<td>" . $row['code'] . "</td>";
echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['date'] . "</td>";
echo "</tr>";
}
echo "</table>";
echo '</div>';
mysqli_close($db);
        
}
}
?>

</div>
</div>

</body>
</html>