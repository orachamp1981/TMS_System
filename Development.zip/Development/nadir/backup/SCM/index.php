<?php
 include("config.php");
 session_start();
$username = "";
if (isset($_POST['submit'])){
	$user = $_POST['user'];
    $pass = $_POST['pass'];
$_SESSION['username'] = $_POST['user'];
$_SESSION['rights']   = $GLOBALS['r'];

    $sql = "SELECT username FROM users WHERE username ='$user' and password = '$pass' LIMIT 1";
    if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
} 

$sql = "SELECT username, Admin_right FROM users WHERE username ='$user' and password = '$pass' LIMIT 1";
$result = $db->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "username: " . $row["username"]. " - Admin_right: " . $row["Admin_right"]. "<br>";
        $rights=$row["Admin_right"];
        $GLOBALS['r'] =$rights;
        $_SESSION["rights"] =$GLOBALS['r'];


    }
} else {
    echo "0 results";
          $rights="";
}

        if($stmt = mysqli_prepare($db, $sql)){
            // Set parameters
            $param_username = trim($_POST["user"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){

                // store result 
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "Welcome '$user'.";
                    echo '<script> alert("'.$username_err.'")</script>';
                    header('Location: home.php');

                } else{
                $username_err = "You are not yet member.";
                echo '<script> alert("'.$username_err.'")</script>';
                }
            } else{
               // echo "Oops! Something went wrong. Please try again later.";
                $username_err = "You are not yet member.";
                echo '<script> alert("'.$username_err.'")</script>';

            }
        }

	/*if ($user == 'admin'){
	if ($pass == 'password'){
	$error ='';
	$success = 'Welcome Admin!!!';
	//echo $success;
 echo '<script> alert("'.$success.'")</script>';
}
	else {
	$error ='Error wrong password';
	$success = '';
 echo '<script> alert("'.$error.'")</script>';
}
}
*/
}



if (isset($_POST['submitu'])){
// Define variables and initialize with empty values
$username = $password = $confirm_password = $confirm_email = "";
$username_err = $password_err = $confirm_password_err =$confirm_email = "";
 $_SESSION['username'] = $_POST['user'];
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["user"]))){
        $username_err = "Please enter a username.";
    } else{
        // Prepare a select statement
        $user =($_POST["user"]);

        $sql = "SELECT username FROM users WHERE username ='$user' LIMIT 1";
        
/*
$result = mysqli_query($db,$sql) or die(mysql_error());
$numrows = mysql_num_rows($result);
if($numrows > 0)
   {
  //  echo 'Your in';
    $username_err = "This username is already taken.";
    echo '<script> alert("'.$username_err.'")</script>';

   }
/*
else
   {
   $username_err = "Oops! Something went wrong. Please try again later.";
   echo '<script> alert("'.$username_err.'")</script>';
   }

*/
        if($stmt = mysqli_prepare($db, $sql)){
            // Bind variables to the prepared statement as parameters
           // mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["user"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){

                // store result 
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                    echo '<script> alert("'.$username_err.'")</script>';

                } else{
                    $username = trim($_POST["user"]);
                }
            } else{
               // echo "Oops! Something went wrong. Please try again later.";
                $username_err = "Oops! Something went wrong. Please try again later.";
                echo '<script> alert("'.$username_err.'")</script>';

            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Validate password
    if(empty(trim($_POST["pass"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["pass"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
        echo '<script> alert("'.$password_err.'")</script>';
    } else{
        $password = trim($_POST["pass"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["passr"]))){
        $confirm_password_err = "Please confirm password.";
        echo '<script> alert("'.$confirm_password_err.'")</script>';     
    } else{
        $confirm_password = trim($_POST["passr"]);
        if(empty($password_err) && ($password != $confirm_password)){
        //if(($_POST["pass"]) && ($_POST["passr"])){
            $confirm_password_err = "Password not matched.";
            echo '<script> alert("'.$confirm_password_err.'")</script>';
        }
    }

    // Validate pin code
    if(empty(trim($_POST["pin"]))){
        $password_err = "Please enter a pin.";     
    } elseif(strlen(trim($_POST["pin"])) !== 4){
        $password_err = "Pin should be of 4 digit.";
        echo '<script> alert("'.$password_err.'")</script>';
    } else{
        $password = trim($_POST["pin"]);
    }



    // Validate Email
    if(empty(trim($_POST["email"]))){
        $confirm_password_err = "Please confirm email.";     
        echo '<script> alert("'.$confirm_password_err.'")</script>';

    } /*else{
        $confirm_password = trim($_POST["email"]);
        if(empty($password_err) && ($password != $confirm_email)){
         $confirm_email = "Password did not match.";
         echo '<script> alert("'.$confirm_email.'")</script>';
        }
    }
*/
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err))

    {
        
        // Prepare an insert statement
        $user =($_POST["user"]);
        $pass =($_POST["pass"]);
        $email= ($_POST["email"]);
        $sql = "INSERT INTO users (username, password, email, Admin_right, PIN_CODE) VALUES ('$user','$pass','$email', 'N', '$pin')";
        //$sql = "INSERT INTO users (username, password, comments) VALUES ('sapna1', 'sapna1', 'sitara')";

if(mysqli_query($db, $sql)){
//    echo "Records added successfully.";
      $success="New record created successfully";
      echo '<script> alert("'.$success.'")</script>';

} else{
    //echo "ERROR: Could not able to execute $sql. " . mysqli_error($db);
      $error="Record not created";
      echo '<script> alert("'.$error.'")</script>';

}
 
       /* if($stmt = mysqli_prepare($db, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $_POST["user"], $_POST["pass"], $_POST["pass"] );
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                //header("location: login.php");
                $success="New record created successfully";
			  echo '<script> alert("'.$success.'")</script>';

            } else{
                echo "Something went wrong. Please try again later.";
                $success="New record created successfully";
			  echo '<script> alert("'.$success.'")</script>';

            }
        }*/
        
        // Close statement
  //      mysqli_stmt_close($stmt);
    }
    
    // Close connection
//    mysqli_close($db);
}
}



?>

<!DOCTYPE html>
<html>
<head>
				<link rel="stylesheet" type="text/css" href="css/style.css">

	<title></title>
   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
      <html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
      
</head>
	<meta charset="utf-8">

<body>
<div class="login-wrap">
	<div class="login-html">
		<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
		<div class="login-form" >
			<div class="sign-in-htm">
				<form method="post">
				<div class="group">
					<label for="user" class="label">Username</label>
					<input id="user" name ="user" type="text" class="input" required="required">
				</div>
				<div class="group">
					<label for="pass" class="label">Password</label>
					<input id="pass" name="pass" type="password" class="input" data-type="password" required="required">
				</div>
				<div class="group">
					<input id="check" type="checkbox" class="check" checked>
					<label for="check"><span class="icon"></span> Keep me Signed in</label>
				</div>
				<div class="group">
					<input type="submit" name="submit" class="button" value="Sign In">
				</div>
				</form>
				<div class="hr"></div>
				<div class="foot-lnk">
					<a href="forgot.php">Forgot Password?</a>
				</div>
		   
			</div>

				<div class="sign-up-htm">
				<form method="post">
				<div class="group">
					<label for="user" class="label">Username</label>
					<input id="user" name = "user" type="text" class="input">
				</div>
				<div class="group">
					<label for="pass" class="label">Password</label>
					<input id="pass" name = "pass" type="password" class="input" data-type="password">
				</div>
				<div class="group">
					<label for="pass" class="label">Repeat Password</label>
					<input id="passr" name = "passr" type="password" class="input" data-type="password">
				</div>
                <div class="group">
                    <label for="pin" class="label">Pin Code</label>
                    <input id="pin" name = "pin" type="pin" class="input">
                </div>
                
                  
                  <div class="group">
					<label for="email" class="label">Email Address</label>
					<input id="email" name = "email" type="text" class="input">
				</div>
				<div class="group">
					<input type="submit" name="submitu" class="button" value="Sign Up">
				</div>
				</form>
				<div class="hr"></div>
				<div class="foot-lnk">
					<label for="tab-1">Already Member?</a>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>