<?php
include("config.php");
session_start();

if(isset($_POST['submit']))
{
$user_id  =$_POST['user'];
$email_id =$_POST['email'];
$result = mysqli_query($db,"SELECT * FROM users where username='" . $_POST['user'] . "'");
$row = mysqli_fetch_assoc($result);
$fetch_user_id=$row['username'];
$fetch_email_id=$row['email'];
$password=$row['password'];
$fetch_password=$row['password'];
$email_id_r=$row['email'];
$fetch_pin_code=$row['PIN_CODE'];
$pin_code =$_POST['pin'];
$Admin_right=$row['Admin_right'];

/*  
if($user_id==$fetch_user_id) {
$to = $email_id;
$to = "gotsomeone@hotmail.com"; 
$subject = "Password";
$txt = "Your password is : $password.";
$from = "anonymousopinionfloat@gmail.com";
$headers = "From:" . $from;
@mail($to,$subject,$txt,$headers);
echo '<script> alert("'.$email_id.'")</script>';

$headers = 'From: '.$from."\r\n".
'Reply-To: '.$from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($to, $subject, $txt, $headers);   
  
  
  
}
else{
echo 'invalid userid';
}
*/

if($user_id==$fetch_user_id && $email_id==$fetch_email_id && $fetch_pin_code == $pin_code) {
    echo '<script> alert(" Your passworid is '.$fetch_password.'")</script>';
    }
    elseif ($user_id==$fetch_user_id && $email_id==$fetch_email_id && $fetch_pin_code !== $pin_code) {
    echo '<script> alert("Your pin code is not correct ")</script>';
    }
    elseif ($user_id==$fetch_user_id && $email_id!==$fetch_email_id && $fetch_pin_code !== $pin_code) {
    echo '<script> alert("Your email id and pin code is not correct ")</script>';
    }

else{
    echo '<script> alert("Provided information is wrong ")</script>';
}


  
}

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<title></title>
</head>
<body>
<div class="login-wrap">
	<div class="login-html">
		<!--input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label-->
		<input id="tab-2" type="radio" name="tab" class="sign-up">
        <label for="tab-2" class="tab">Forgot Password Click Here</label>
		<div class="login-form" >
				<div class="sign-up-htm">
				<form method="post">
				<div class="group">
					<label for="user" class="label">Username</label>
					<input id="user" name = "user" type="text" class="input">
				</div>
				<!--div class="group">
					<label for="pass" class="label">Password</label>
					<input id="pass" name = "pass" type="password" class="input" data-type="password">
				</div-->
				<!--div class="group">
					<label for="pass" class="label">Repeat Password</label>
					<input id="passr" name = "passr" type="password" class="input" data-type="password">
				</div-->
				<div class="group">
					<label for="email" class="label">Email Address</label>
					<input id="email" name = "email" type="text" class="input">
				</div>
                  
                  				<div class="group">
					<label for="pin" class="label">Pin Code</label>
					<input id="pin" name = "pin" type="text" class="input">
				</div>

				<div class="group">
					<input type="submit" name="submit" class="button" value="Recover Password">
				</div>
				</form>
				<div class="hr"></div>
				<div class="foot-lnk">
					<label for="tab-1">All Rights Reserved By Orachamp</a>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>