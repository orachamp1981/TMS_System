<?php
 include("config.php");
 session_start();
//echo $_SESSION["username"];
$loggenOnUser=substr(ucwords($_SESSION["username"]),0,2);
$loggenOnRights =$_SESSION["rights"];
//echo '<script> alert("'.$loggenOnRights.'")</script>';

?>
<!DOCTYPE html>
<html>
<html lang="en">
<head class>
  <title> </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/style2.css">


</head>

	  <title> ERP User:- <?php echo $loggenOnUser; ?> </title>

<body>
    <!-- Navigation -->
<div>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Supply Chain Management</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
         <li class="active"><a href="home.php">Home</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="index.php">Main<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="country.php">Country</a></li>
            <li><a href="city.php">City</a></li>
            <li><a href="#">Page 1-3</a></li>
            <li><a href="#">Page 1-4</a></li>
          </ul>
        </li>
        <li><a href="#">Page 2</a></li>
        <li><a href="#">Page 3</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <!--li><a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo $loggenOnUser; ?></a></li-->
        <li><a href="index.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
 </div>

 <div class="login-html1">
     <h1> This is new form</h1>
 </div>
</body>
</html>