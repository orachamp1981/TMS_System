<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<h1 style="color: darkblue">"Yokohama"</h1>
<body>
<p>"A great wrestler"</p>
<h2>My first PHP page</h2>

<?php
echo "Hello World!";
?>

<br>

<?php
$color = 'red';

echo "The color is " .$color. "<br>";
?>

<?php
//database parameter
$db_name = "drpluto";
$user = "erp";
$password = "erp1";
$sid = "DRPLUTO";
$port = "1521";

//function of connection
$conn = oci_connect($user, $password, "//172.28.1.32/".$db_name);
//$conn = oci_connect ($user, $password, "//localhost/".$db_name);
$sql = "SELECT count(prvdr_id) FROM med_provider_main";

?> 


</body>
</html>