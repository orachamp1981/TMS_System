<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="E:/nadir/css/styles.css">
</head>

<body>

<?php
try {
   $db_name = "drpluto";
$user = "erp";
$password = "erp1";
$sid = "DRPLUTO";
$port = "1521";
//use phpGrid\C_DataGrid;

//function of connection
//$conn = oci_connect($user, $password, "//172.28.1.32/".$db_name);
$conn = oci_connect($user, $password, "//172.28.1.32/".$db_name);

} 
catch (PDOException $e) {
    //echo 'Connection failed: ' . $e->getMessage();
    exit;
}

$sql = 
"DECLARE
    rs_tm 			varchar2(100); 
    rs_vl 			varchar2(100);

BEGIN
   BILLED_AMOUNT (:i_p_ref, :param2_out :param3_out, :param4_out, :param5_out, :param6_out););

END; ";  // Added semi-colon after END

$stid = oci_parse($conn, $sql);
//oci_execute($stmt);

/*while (($row = oci_fetch_array($stmt, OCI_BOTH)) != false) {
    // Use the uppercase column names for the associative array indices
    echo $row[0] . " and " . $row['DEPARTMENT_ID']   . " are the same<br>\n";
    echo $row[1] . " and " . $row['DEPARTMENT_ID1']   . " are the same<br>\n";
    echo $row[2] . " and " . $row['DEPARTMENT_ID2']   . " are the same<br>\n";
    echo $row[3] . " and " . $row['DEPARTMENT_ID3']   . " are the same<br>\n";
    echo $row[4] . " and " . $row['DEPARTMENT_NAME'] . " are the same<br>\n";
}
*/
    $v_instance_name = 'EM/13-000014-06';

	oci_bind_by_name($stid, ':i_p_ref', $v_instance_name);
    oci_bind_by_name($stid, ':param2_out', $v_ts1,100);
    oci_bind_by_name($stid, ':param3_out', $v_ts2,100 );
    oci_bind_by_name($stid, ':param4_out', $v_ts2,100);
    oci_bind_by_name($stid, ':param5_out', $v_result_timestamp,100);
    oci_bind_by_name($stid, ':param6_out', $v_result_value,100);
    oci_execute($stid);

 echo "<td>".$v_result_timestamp."</td><td>".$v_result_value."</td>";
 

?>

</body>
</html>