<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Enterprise Resource Planning</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Popper.js/1.12.9/umd/Popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
	<link   href="css/style.css" rel="stylesheet">
	<script type="text/javascript" src="javascript.js"></script>
  <style>
* {box-sizing: border-box}
body {font-family: "Lato", sans-serif;}

/* Style the tab */
.tab {
    float: left;
    margin-left:5px;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
    width: 20%;
    height: 400px;
}

/* Style the buttons inside the tab */
.tab button {
    display: block;
    background-color: inherit;
    color: black;
    padding: 22px 16px;
    width: 100%;
    border: none;
    outline: none;
    text-align: left;
    cursor: pointer;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
    background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    float: left;
    padding: 0px 12px;
    border: 1px solid #ccc;
    width: 77%;
    border-left: none;
    height: 400px;
}
</style>

</head>
<body>
<!-- Navigation -->

<div class="topnav">
  <a class="active" href="index.php">Home</a>
  <a href="about.php">About</a>
  <a href="#contact">Guidelines</a>

  <div class="topnav-right">
    <a><a href="indexlogin.php">Login <span class="glyphicon glyphicon-user"></span></a></a>
    <!--a href="#about">About</a-->
  </div>
</div>


<!-- Two Column Section -->


<!--Footer-->
<footer style="background-color: #3b5998;">
<h5 align="center" style="color:white;">&copy; Orachamp1981</h5>

</div>
	<!--/div-->
	
</div>
</footer>
</body>
</html>