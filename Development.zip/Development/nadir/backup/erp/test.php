
       
        

       
       <!DOCTYPE html>
<html class="no-js">
    <head>	
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=10">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="image/png" href="images/favicon.png">
        <title>Allianz EFU Health Insurance Limited - Portal</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
		<!-- Favicons
		================================================== -->
		<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
		<link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
		<link rel="manifest" href="favicon/manifest.json">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
		<meta name="theme-color" content="#ffffff">        
		
		<!-- Mobile Specific Metas
        ================================================== -->
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width, initial-scale=1">		
        
        <!-- Template CSS Files
        ================================================== -->
        <!-- Twitter Bootstrs CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">	
        <!-- Ionicons Fonts Css -->
        <link rel="stylesheet" href="css/ionicons.min.css">
		 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">		
        <!-- animate css -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- Hero area slider css-->
        <link rel="stylesheet" href="css/slider.css">
        <!-- owl craousel css -->
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/owl.theme.css">
        <link rel="stylesheet" href="css/jquery.fancybox.css">
        <!-- template main css file -->
        <link rel="stylesheet" href="css/main.css">
        <!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">

		<!-- font Awesome http://fontawesome.io -->
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
		<!-- font Awesome http://fontawesome.io -->

        <!-- Template Javascript Files
        ================================================== -->
		<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <!-- modernizr js -->
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <!-- jquery -->
        <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- owl carouserl js -->
        <script src="js/owl.carousel.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!-- wow js -->
        <script src="js/wow.min.js"></script>
        <!-- slider js -->
        <script src="js/slider.js"></script>
        <script src="js/jquery.fancybox.js"></script>
        <!-- template main js -->
        <script src="js/main.js"></script>

		<!-- Include the plugin's CSS and JS: -->
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
		<script type="text/javascript" src="js/bootstrap-multiselect.js"></script>
		<link rel="stylesheet" href="css/bootstrap-multiselect.css" type="text/css"/>

		<!-- Fira Code Ligatures -->
		<link rel="stylesheet" href="https://cdn.rawgit.com/tonsky/FiraCode/1.205/distr/fira_code.css">
		<!-- Fira Code Ligatures -->

		<!-- Dropzone -->

		<!-- Dropzone -->

		<!-- Check Browser Version -->

		<script> 
		var $buoop = {required:{e:-4,f:-3,o:-3,s:-1,c:-3},insecure:true,api:2018.09 }; 
		function $buo_f(){ 
		 var e = document.createElement("script"); 
		 e.src = "//browser-update.org/update.min.js"; 
		 document.body.appendChild(e);
		};
		try {document.addEventListener("DOMContentLoaded", $buo_f,false)}
		catch(e){window.attachEvent("onload", $buo_f)}
		</script>
		
		<!-- /Check Browser Version -->

	

		<!-- Pnotify Jqurey Plugin -->

		<script type="text/javascript" src="js/pnotify.custom.min.js">
		</script>
		<link href="css/pnotify.custom.min.css" media="all" rel="stylesheet" type="text/css" />
		<link href="//cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css" rel="stylesheet" type="text/css" />

		<!-- /Pnotify Jqurey Plugin -->

		<!-- Condional Fields Jqurey Plugin -->

		<script type="text/javascript"  src="js/CondionalFields/conditional-field.min.js"></script>

		<!-- /Condional Fields Jqurey Plugin -->

		<!-- Custom CSS Files -->
			<style>

				.thumbnail {
					padding:0px;
				}
				.panel {
					position:relative;
				}
				.panel>.panel-heading:after,.panel>.panel-heading:before{
					position:absolute;
					top:11px;left:-16px;
					right:100%;
					width:0;
					height:0;
					display:block;
					content:" ";
					border-color:transparent;
					border-style:solid solid outset;
					pointer-events:none;
				}
				.panel>.panel-heading:after{
					border-width:7px;
					border-right-color:#f7f7f7;
					margin-top:1px;
					margin-left:2px;
				}
				.panel>.panel-heading:before{
					border-right-color:#ddd;
					border-width:8px;
				}
				
			</style>

		<!-- Custom CSS Files -->

		<!-- Custom JS Files -->
		<script src="js/formPrint.js"></script>

		<script>
		function deleteHistoryRecord(varId)
		{
			// alert(varId);
			$.post("index.php",
			{
			page: 'DeleteHistory',
			HistoryId: varId
			},
				function(data, status)
				{
					// alert("Data: " + data + "\nStatus: " + status);
					var response=jQuery.parseJSON(data);
					// alert(resposnse);
					if(typeof response =='object')
					{
			            if(response.response.status == "Error")
			            {
	                        $("#result").removeClass(); 
	                        document.getElementById('result').classList.add('alert');
	                        document.getElementById('result').classList.add('alert-danger');  
			            }
			            else
			            {
	                        $("#result").removeClass();  
	                        document.getElementById('result').classList.add('alert');
	                        document.getElementById('result').classList.add('alert-success');
			            }
				            $("#result").html(response.response.description);
				            $("#result").fadeTo(2000, 500).slideUp(500, function(){
				            $("#result").slideUp(500);
			            });                                                                                                                                           
					}
					else
					{
						if(response !=true)
						{
			                $("#result").html(data)
						}
						else
						{
						    location.reload();
						}
					}                                                                              
				});
			
			location.reload();                                                     
		}

		</script>
		<!-- Custom JS Files -->

		<style type="text/css">
			input[data-readonly] {
			  pointer-events: none;
			}
		</style>

		<script type="text/javascript">
		$(document).ready(function() {
			$('#removesubsciber').multiselect({
				includeSelectAllOption: true,
				enableFiltering: true,
				enableCaseInsensitiveFiltering: true,
				maxHeight: 150
			});
			$('#subsciber').multiselect({
				includeSelectAllOption: true,
				enableFiltering: true,
				enableCaseInsensitiveFiltering: true,
				maxHeight: 150
			});
		});

		function myFunction() {
			var x, text;

			// Get the value of the input field with id="numb"
			x = document.getElementById("numb").value;

			// If x is Not a Number or less than one or greater than 10
			if (isNaN(x) || x < 1 || x > 10) {
				text = "Input not valid";
			} else {
				text = "Input OK";
			}
			document.getElementById("demo").innerHTML = text;
		}


		</script>

						
		<script type="text/javascript">
		function statusFormValidate()
		{
			new PNotify({
				    title: 'Confirmation Needed',
				    text: 'Are you sure you want to update the Status? <b> Once status updated you cannot update again </b>.',
				    icon: 'glyphicon glyphicon-question-sign',
				    hide: false,
				    confirm: {
				        confirm: true
				    },
				    buttons: {
				        closer: false,
				        sticker: false
				    },
				    animate: {
				        animate: true,
				        in_class: 'zoomInLeft',
				        out_class: 'zoomOutRight'
				    },
				    history: {
				        history: false
				    }
				}).get().on('pnotify.confirm', function() {
				  return true
				}).get().on('pnotify.cancel', function() {
				    return false
				})			
		}

		$(document).ready(function(){
																																													
						
			$("form").on("submit",function(event)
			{
				// Stop form from submitting normally
				event.preventDefault();
				//alert($('form').serialize());
				var formid = $(this).attr('id');
				if(formid == "memberFormStatus")
				{
					var Allowed;
					var r = confirm("Are you sure you want to update the Status? Once status updated you cannot update again.");
					if (r == true) 
					{
					   // Allowed = true;
					} 
					else 
					{
					    Allowed = false;
					    return Allowed;
					}

				}

				if(formid == "AnnouncementFiler")
				{
					var AnuStart = document.getElementById('AnuDateStart');
					var AnuEnd = document.getElementById('AnuDateEnd');
					var combine = AnuStart.value + "," + AnuEnd.value;
					//alert(combine);
					createObject('GetAnnouncementFiler','AnnouncementList',combine);
				}
				else
				{
				$("#result").removeClass();
				document.getElementById('result').classList.add('alert');
				document.getElementById('result').classList.add('alert-info');
				$("#result").html("Please wait! Processing Request....");
				$("#result").fadeTo(2000, 500).slideUp(500, function(){
				 $("#result").slideUp(500);
					});
					var formData = new FormData(this);
					$.ajax({
						url: window.location.pathname,
						type: 'POST',
						data: formData,
						contentType: false,
						processData: false,
						success: function (data) 
						{
							alert(data);
							if(formid == "ACPolicyListFilter")
                            {
                                var tableRef = document.getElementById("AMPolicyHolderList");	
								try
								{
									tableRef.innerHTML = "";
									var response=jQuery.parseJSON(data);
								}
								catch(e)
								{
									tableRef.innerHTML = data;

								}
                            }
                            if(formid == "ClientMemberListFilter")
                            {
                            	var tableRef = document.getElementById("HRClientMemberList")
                                   	tableRef.innerHTML = data;
									   	document.getElementById("frmTotalPages").value = document.getElementById("TotalPages").innerText;
										createPageslist(document.getElementById("frmTotalPages").value);
                            }
							if(formid == "FormListPage")
                            {
                            	var tableRef = document.getElementById("FHQFEQMembers")
                                   	tableRef.innerHTML = data;
									   	document.getElementById("frmTotalPages").value = document.getElementById("TotalPages").innerText;
										createPageslist(document.getElementById("frmTotalPages").value);
                            }
							var response=jQuery.parseJSON(data);
							if(typeof response =='object')
							{
								if(response.response.status == "Error")
								{
									new PNotify({
									    title: 'Error',
									    text: response.response.description,
									    type: 'error',
									    animate: {
									        animate: true,
									        in_class: 'zoomInLeft',
									        out_class: 'zoomOutRight'
									    }
									});				
								}
								if(response.response.status == "Message")
								{
									new PNotify({
									    title: 'Success!',
									    text: response.response.description,
									    type: 'success',
									    animate: {
									        animate: true,
									        in_class: 'zoomInLeft',
									        out_class: 'zoomOutRight'
									    }
									});
								}
								if(response.response.status == "Status")
								{
									$("#Status").html(response.response.description);
									new PNotify({
									    title: 'Success!',
									    text: response.response.description,
									    type: 'success',
									    animate: {
									        animate: true,
									        in_class: 'zoomInLeft',
									        out_class: 'zoomOutRight'
									    }
									});
								}								
							}
							else
							{
							  if(response !=true)
							  {
								//  $("#result").html(data)
								new PNotify({
									    title: 'Notice',
									    text: data,
									    type: 'notice',
									    animate: {
									        animate: true,
									        in_class: 'zoomInLeft',
									        out_class: 'zoomOutRight'
									    }
									});	
							  }
							  else
							  {
								location.reload();
							  }
							}								
						},
						cache: false
					});
				// });
																																												}
			});
		});
		</script>
		<script type="text/javascript">
			function getandfill(varObject,fromObject,varFillControl)
			{
				var fillme = document.getElementById(varFillControl);
				var objIndex = fromObject.selectedIndex;
				
				$.post("datalist.php",
				{
					getObject: varObject,
					ObjectId: objIndex
				},
				function(data, status){
					//alert("Data: " + data + "\nStatus: " + status);
					var response=jQuery.parseJSON(data);
					if(data != '[false]')
					{
						fillme.value = response[0]['MESSAGE'];
					}
					else
					{
						fillme.value = '';
					}
				});				
			}
			function createObject(varObject,varInto,objIndex)
			{
				//alert(varObject);
				$.post("datalist.php",
				{
					getObject: varObject,
					ObjectId: objIndex
				},
				function(data, status){
					//alert("Data: " + data + "\nStatus: " + status);
					var tableRef = document.getElementById(varInto)
					//var response=jQuery.parseJSON(data);
					if(status = 'success')
					{
						tableRef.innerHTML = data;
					}
					else
					{
						fillme.value = '';
					}
				});
			}
		</script>		
    </head>    <body>
        <!--
        ==================================================
        Header Section Start
        ================================================== -->
        <header id="top-bar" class="navbar-fixed-top animated-header">
            <div class="container">
                <div class="navbar-header" style="width:60%">
                    <!-- responsive nav button -->
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only" >Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <!-- /responsive nav button -->
                    
                    <!-- logo -->
                    <div class="navbar-brand">
                        <a href="index.php" >
                           <img src="images/logo-original.png" alt="" width="45%" height="45%"> 
                        </a>
                    </div>
                    <!-- /logo -->
                </div>
                <!-- main menu -->
                <nav class="collapse navbar-collapse navbar-right" role="navigation">
                    <div class="main-menu">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="http://www.allianzefu.com" target="_blank" >Our Official Website</a>
                            </li>
                            <li><a href="index.php">Portal Home</a></li>
                            <li><a href="index.php?page=feedback">Feedback Form</a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">samreen                                            
                                            <span class="caret"></span></a>
                                                                            <div class="dropdown-menu">
                                    <ul>                                       
                                                                                    <li><a href="logout.php">Logout</a></li>
                                                                            </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- /main nav -->
            </div>
        </header><br/><br/><br/><br/><br/><br/>
        
            <section id="about">
                <div class="container">
				<form id="contact-form" method="post" action="index.php" role="form">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="block wow fadeInLeft" data-wow-delay=".3s" data-wow-duration="500ms">
                                <h2>
                                </br>Dashboard
                                </h2>
                                <p>
									<div class="row">
										<div class="col-sm-3">
											 <figure class="wow fadeInLeft animated portfolio-item animated" data-wow-duration="300ms" data-wow-delay="0ms" style="visibility: visible; animation-duration: 300ms; -webkit-animation-duration: 300ms; animation-delay: 0ms; -webkit-animation-delay: 0ms; animation-name: fadeInLeft; -webkit-animation-name: fadeInLeft;">
												<div class="img-wrapper">
													<img src="images/portal/dashboard/dashboard-Portal.png" class="img-responsive" alt="portfolio items">
													<div class="overlay">
														<div class="buttons">
															<!--a rel="gallery" title="Proin imperdiet augue et magna interdum hendrerit" class="fancybox" href="images/portfolio/item-1.jpg">Demo</a-->        
															<a href="index.php?page=About">Visit Now</a>
														</div>
													</div>
												</div>
												<figcaption>
													<h4>
														<a href="index.php?page=About">
																Portal
														</a>
													</h4>
													<p>
														One Portal for all Allianz EFU stakeholders.
													</p>
												</figcaption>
											</figure>
										</div>

										<div class="col-sm-3">
											<figure class="wow fadeInLeft animated animated" data-wow-duration="300ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 300ms; -webkit-animation-duration: 300ms; animation-delay: 300ms; -webkit-animation-delay: 300ms; animation-name: fadeInLeft; -webkit-animation-name: fadeInLeft;">
												<div class="img-wrapper">
													<img src="images/portal/dashboard/dashboard-SMS.png" class="img-responsive" alt="portfolio items">
													<div class="overlay">
														<div class="buttons">
															<!--a rel="gallery" title="Proin imperdiet augue et magna interdum hendrerit" class="fancybox" href="images/portfolio/item-2.jpg">Demo</a-->        
															<a href="index.php?page=SMS">Visit Now</a>
														</div>
													</div>
												</div>
												<figcaption>
													<h4>
														<a href="index.php?page=SMS">
															SMS for You       
														</a>
													</h4>
													<p>
														Send SMS alerts to Allianz EFU's Employees.
													</p>
												</figcaption>
											</figure>
										</div>

										<div class="col-sm-3">
											<figure class="wow fadeInLeft animated animated" data-wow-duration="300ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 300ms; -webkit-animation-duration: 300ms; animation-delay: 300ms; -webkit-animation-delay: 300ms; animation-name: fadeInLeft; -webkit-animation-name: fadeInLeft;">
												<div class="img-wrapper">
													<img src="images/portal/dashboard/dashboard-EMP.png" class="img-responsive" alt="">
													<div class="overlay">
														<div class="buttons">
															<!--a rel="gallery" title="Proin imperdiet augue et magna interdum hendrerit" class="fancybox" href="images/portfolio/item-3.jpg">Demo</a-->        
															<a href="index.php?page=EmployeeDashboard">Visit Now</a>
														</div>
													</div>
												</div>
												<figcaption>
													<h4>
														<a href="index.php?page=EmployeeDashboard">
															Employees Portlet       
														</a>
													</h4>
													<p>
														All you need as a member of Allianz EFU Team.
													</p>
												</figcaption>
											</figure>
										</div>
									
										<div class="col-sm-3">
											<figure class="wow fadeInLeft animated animated" data-wow-duration="300ms" data-wow-delay="600ms" style="visibility: visible; animation-duration: 300ms; -webkit-animation-duration: 300ms; animation-delay: 600ms; -webkit-animation-delay: 600ms; animation-name: fadeInLeft; -webkit-animation-name: fadeInLeft;">
												<div class="img-wrapper">
													<img src="images/portal/dashboard/dashboard-Client.png" class="img-responsive" alt="">
													<div class="overlay">
														<div class="buttons">
															<!--a rel="gallery" title="Proin imperdiet augue et magna interdum hendrerit" class="fancybox" href="images/portfolio/item-4.jpg">Demo</a-->        
															<a href="index.php?page=FormList">Visit Now</a>
														</div>
													</div>
												</div>
												<figcaption>
													<h4>
														<a href="index.php?page=FormList">
															Client        
														</a>
													</h4>
													<p>
														Help our customers get their limitations.
													</p>
												</figcaption>
											</figure>
										</div>

										<div class="col-sm-3">
											<figure class="wow fadeInLeft animated animated" data-wow-duration="300ms" data-wow-delay="600ms" style="visibility: visible; animation-duration: 300ms; -webkit-animation-duration: 300ms; animation-delay: 600ms; -webkit-animation-delay: 600ms; animation-name: fadeInLeft; -webkit-animation-name: fadeInLeft;">
												<div class="img-wrapper">
													<img src="images/portal/dashboard/dashboard-CRM.png" class="img-responsive" alt="">
													<div class="overlay">
														<div class="buttons">
															<!--a rel="gallery" title="Proin imperdiet augue et magna interdum hendrerit" class="fancybox" href="images/portfolio/item-4.jpg">Demo</a-->        
															<a href="index.php?page=CRM">Visit Now</a>
														</div>
													</div>
												</div>
												<figcaption>
													<h4>
														<a href="index.php?page=CRM">
															CRM        
														</a>
													</h4>
													<p>
														To manage protal Allianz EFU Clients on Portal.
													</p>
												</figcaption>
											</figure>
										</div>										

										<div class="col-sm-3">
											<figure class="wow fadeInLeft animated animated" data-wow-duration="300ms" data-wow-delay="600ms" style="visibility: visible; animation-duration: 300ms; -webkit-animation-duration: 300ms; animation-delay: 600ms; -webkit-animation-delay: 600ms; animation-name: fadeInLeft; -webkit-animation-name: fadeInLeft;">
												<div class="img-wrapper">
													<img src="images/portal/dashboard/dashboard-Doctors.png" class="img-responsive" alt="">
													<div class="overlay">
														<div class="buttons">
															<!--a rel="gallery" title="Proin imperdiet augue et magna interdum hendrerit" class="fancybox" href="images/portfolio/item-4.jpg">Demo</a-->        
															<a href="index.php?page=doctors">Visit Now</a>
														</div>
													</div>
												</div>
												<figcaption>
													<h4>
														<a href="index.php?page=doctors">
															Doctors        
														</a>
													</h4>
													<p>
														Help our customers get their limitations.
													</p>
												</figcaption>
											</figure>
										</div>													
									</div>
                                </p>
                            </div> 
                        </div>
                    </div>
				</form>
                </div>
            </section> <!-- /#about -->
            <!--
            ==================================================
            Call To Action Section Start
            ================================================== -->
            <section id="call-to-action">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="block">
                                <h2 class="title wow fadeInDown" data-wow-delay=".3s" data-wow-duration="500ms">About Us</h1>
                                <p class="wow fadeInDown" data-wow-delay=".5s" data-wow-duration="500ms">Allianz EFU is Pakistan's First specialized health insurance company. It was incorporated on May 15, 2000 as a joint venture of Pakistan's largest insurance group, EFU with Allianz SE which is one of the largest composite insurers in the world with active presence across the globe. Together, Allianz and EFU bring over 190 years of experience to make quality healthcare accessible and affordable.</p>
                                <a href="index.php?page=feedback" class="btn btn-default btn-contact wow fadeInDown" data-wow-delay=".7s" data-wow-duration="500ms">Contact Us</a>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section>            <!--
            ==================================================
            Footer Section Start
            ================================================== -->
			<br/><br/><br/><br/>
            <footer id="footer"  class="navbar navbar-default navbar-fixed-bottom">
                <div class="container">
                    <div class="col-md-6">
                        <p class="copyright">Copyright: <span>2017</span> . Design and Developed by <a href="http://www.allianzefu.com"><b>Allianz EFU Health Insurance Ltd.</b></a></p>
                    </div>
                    <div class="col-md-6">						
                        <!-- Social Media -->
                        <ul class="social">
							<li>
                                <a href="https://goo.gl/3q5JS4" target="_blank">
                                    <i class="ion-social-apple"></i>
                                </a>
							</li>
							<li>
                                <a href="https://goo.gl/L8p1tG" target="_blank">
                                    <i class="ion-social-android"></i>
                                </a>
							</li>						
                            <li>
                                <a href="#" class="Facebook">
                                    <i class="ion-social-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="Twitter">
                                    <i class="ion-social-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="Linkedin">
                                    <i class="ion-social-linkedin"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="Google Plus">
                                    <i class="ion-social-googleplus"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </footer> <!-- /#footer -->

            <script type="text/javascript">
                function sendHRClientInvitation(varInvitationForm,varInvitationId)
                {

                    document.getElementById('varHRClientId').value = document.getElementById('Id_'+varInvitationId).innerHTML;
                    document.getElementById('varHRClientName').value = document.getElementById('ClientName_'+varInvitationId).innerHTML;

                    document.getElementById('varContactPerson').value = document.getElementById('ContactPerson_'+varInvitationId).innerHTML;                            
                    document.getElementById('varDesignation').value = document.getElementById('Title_'+varInvitationId).innerHTML;

                    document.getElementById('varEmail').value = document.getElementById('Email_'+varInvitationId).innerHTML; 

     //                varClientId = document.getElementById('varHRClientId').value;

     //                varObject = "getPlanList";
     //                $.post("datalist.php",
     //                {
     //                    getObject: varObject,
     //                    ObjectId: varClientId
     //                },
     //                function(data, status)
     //                {

     //                    if(status = 'success')
     //                    {
     //                        var objSelect = document.getElementById("InsurancePlan");
     //                        document.getElementById("InsurancePlan").options.length = 0;
     //                        map = { };
     //                        $(data).each(function(_, node) {
     //                        objSelect.options.add( new Option(node.text,node.value) );
     //                        });
     //                    }
					// });
                }

                function reinviteClientHR(varInvitationForm,varInvitationId)
                {
                    document.getElementById('varInvitationId').value = document.getElementById('Id_'+varInvitationId).innerHTML;

                    document.getElementById('varClientId').value = document.getElementById('ClientId_'+varInvitationId).innerHTML;

                    document.getElementById('varfullName').value = document.getElementById('Full_name_'+varInvitationId).innerHTML;

                    document.getElementById('varEmail').value = document.getElementById('Email_'+varInvitationId).innerHTML;
                }

                function sendHRClientMemberInvitation(varInvitationForm,varRowId)
                {
                    document.getElementById('varCertId').value = document.getElementById('Cert_Id_'+varRowId).innerHTML;

                    document.getElementById('varCardName').value = document.getElementById('Member_Name_'+varRowId).innerHTML;

                    document.getElementById('varRelation').value = document.getElementById('Relation_'+varRowId).innerHTML;

                    document.getElementById('varEmailAddress').value = document.getElementById('Email_Address_'+varRowId).innerHTML;

                    document.getElementById('varEffectiveDate').value = document.getElementById('Effective_Date_'+varRowId).innerHTML;

                }

                function sendHRClientMemberReinvitation(varInvitationForm,varRowId)
                {
                    document.getElementById('varCertId').value = document.getElementById('Cert_id_'+varRowId).innerHTML;

                    document.getElementById('varInvitationId').value = document.getElementById('InvitationId_'+varRowId).innerHTML;

                    document.getElementById('varClientId').value = document.getElementById('ClientId_'+varRowId).innerHTML;

                    document.getElementById('varMemberName').value = document.getElementById('MemberName_'+varRowId).innerHTML;

                    document.getElementById('varMemberEmail').value = document.getElementById('MemberEmail_'+varRowId).innerHTML;
                }


                function submitForm()
                {
                    $.ajax({
                        url:'index.php',
                        type:'post',
                        data:$('#FRMClientRegistration').serialize(),
                        success:function(data){
                            // alert(data);
                        var response=jQuery.parseJSON(data);
                        if(typeof response =='object')
                        {
                            if(response.response.status == "Error")
                            {
                                $("#result").removeClass(); 
                                document.getElementById('result').classList.add('alert');
                                document.getElementById('result').classList.add('alert-danger');                            
                            }
                            else
                            {
                                $("#result").removeClass();  
                                document.getElementById('result').classList.add('alert');
                                document.getElementById('result').classList.add('alert-success');
                            }
                            $("#result").html(response.response.description);
                            $("#result").fadeTo(2000, 500).slideUp(500, function(){
                                            $("#result").slideUp(500);
                                            });                                 
                        }
                        else
                        {
                            if(response !=true)
                            {
                                $("#result").html(data)
                            }
                            else
                            {
                            location.reload();
                            }
                        }
                        }
                    });
                }

                function createPageslist(numberPages)
                {
                    var objSelect = document.getElementById("ddlPages");

                    document.getElementById("ddlPages").options.length = 0;
                    for(a=1;a<=numberPages;a++)
                    {
                        objSelect.options.add( new Option('Page ' + a,a) );
                    }
                    document.getElementById("ddlPages").selectedIndex = document.getElementById('pageNo').value -1;
                }
            </script>                
        </body>
    </html>