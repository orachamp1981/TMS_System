<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Enterprise Resource Planning</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Popper.js/1.12.9/umd/Popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
	<link   href="css/style.css" rel="stylesheet">
	<script type="text/javascript" src="javascript.js"></script>
</head>
<body>
<!-- Navigation -->

<div class="topnav">
  <a class="active" href="index.php">Home</a>
  <a href="about.php">About</a>
  <a href="#contact">Documentation</a>

  <div class="topnav-right">
    <a><a href="indexlogin.php">Login <span class="glyphicon glyphicon-user"></span></a></a>
    <!--a href="#about">About</a-->
  </div>
</div>
<br>

<!-- Two Column Section -->


<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h2>About Builder</h2>
      <div class="fakeimg">
      <img src="images/nad1.jpg">
      </div>
      <h4>Profile Link</h4>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="https://www.linkedin.com/in/nadir-ali-02095318/" target="_blank">LinkedIn Profile</a></li>
        <!--li><a href="#">Link 2</a></li>
        <li><a href="#">Link 3</a></li-->
      </ul>
      
      <h4>Sample Website</h4>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="http://nadir.epizy.com" target="_blank">Bootstrap Website</a></li>
        <!--li><a href="#">Link 2</a></li>
        <li><a href="#">Link 3</a></li-->
      </ul>
      
      
      <hr class="hidden-sm hidden-md hidden-lg">
    </div>
    <div class="col-sm-8">
      <h3>Introduction</h3>
      <p>I am Nadir Ali holding wide experience in the field of Oracle Application Development on several domains for more information my profile link given aside, during my whole tenure programming, analyzing, working on many tools for building forms and reports. Popular programming techniques exist but mostly workout on structural/procedural, find out myself fast learner, adaptibility approach, self contributor, working with team and lead team.</p>
      <br>
      <p>Development is my passion therefore try level best to deploy user friendly system which hold attribute like ease during operate, minimal software load, processed on summarized information. These attributes are keys for me to produce successful system but sometimes compromise on information but rest remain same.</p>
      <p>The idea behind website development is to transform business logics on simple browser based application as to get rid of restrictions occured during deployment of erp based softwares like platform dependant and others. It might not trnasform to 100% but until what extent it will be applied possible approaches will be followed. First of all I am not web developer but by inaugurating the website will give first step into web development.</p>
      <p>Currently not holding much experience in HTML, CSS, PHP, Javascript, Jquery but time by time and according to need of processess I will achieve the milestone to update and grab enough grib to maiantain and proceed further. There are multiples software engineers who will definetly feedup as how to make this website more attractive and workable so continuous enhancement and changing will be made on website.</p>
      <p> My email address is <b> gotsomeone@hotmail.com </b> for all sorts of queries and feedback.	
    </div>
  </div>
</div>





<!--Footer-->
<footer style="background-color: #3b5998;">
<h5 align="center" style="color:white;">&copy; Orachamp1981</h5>

</div>
	<!--/div-->
	
</div>
</footer>
</body>
</html>