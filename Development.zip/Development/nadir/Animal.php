<?php
class Animal
{
    private $family;
    private $food;
    private $color;
    public function __construct($family, $food, $color)
    {
        $this->family = $family;
        $this->food   = $food;
        $this->color  = $color;
    }
    public function get_family()
    {
        return $this->family;
    }
    public function set_family($family)
    {
        $this->family = $family;
    }
    public function get_food()
    {
        return $this->food;
    }
    public function set_food($food)
    {
        $this->food = $food;
    }

        public function get_color()
    {
        return $this->color;
    }
    public function set_color($color)
    {
        $this->food = $color;
    }
}
?> 