<?php
class Hen extends Animal
{
    public function __construct($family, $food, $color)
    {
        parent::__construct($family, $food, $color);
    }
}
?>