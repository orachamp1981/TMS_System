<?php
require 'Animal.php';
require 'Cow.php';
require 'Lion.php';
require 'Hen.php';

$cow  = new Cow('Herbivore', 'Grass', 'Mix');
$lion = new Lion('Canirval', 'Meat', 'Yellow');
$hen  = new Hen ('Herbivore', 'Grain', 'Red Mix');

echo '<b>Cow Object</b> <br>';
echo 'The Cow belongs to the ' . $cow->get_family() . ' family , eats ' . $cow->get_food() . ' and color is ' .$cow->get_color() . '<br><br>';

echo '<b>Lion Object</b> <br>';
echo 'The Lion belongs to the ' . $lion->get_family() . ' family , eats ' . $lion->get_food(). ' and color is ' .$lion->get_color().'<br><br>';

echo '<b>Hen Object</b> <br>';
echo 'The Hen belongs to the ' . $hen->get_family() . ' family , eats ' . $hen->get_food().' and color is ' .$hen->get_color();
?>