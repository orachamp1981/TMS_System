<?php 
$TodayDate = date("l F d Y, h:i:sa");
$YourName  = "Nadir Ali";
$Department = "IT";
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
Welcome to Zone
<br>
Todays Date  :     
<?php 
echo ($TodayDate);
 ?>
 <br>

 <?php 
echo 'Your Department: ';
echo($Department);
  ?>
</body>
</html>