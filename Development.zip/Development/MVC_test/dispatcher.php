<?php

class Dispatcher
{
    private $request;


    public function dispatch()
    {
        //PRINT_R($this->request);
        $this->request = new Request();
        //PRINT_R($this->request);
        // /MVC_test/
        //print_r($this->request->url); 
        //print_r($this->request);
//PRINT_R($this->request);

        Router::parse($this->request->url, $this->request);

        $controller = $this->loadController();

        call_user_func_array([$controller, $this->request->action], $this->request->params);
       // PRINT_R('request->params');
    }

    public function loadController()
    {
        $name = $this->request->controller . "Controller";
        $file = ROOT . 'Controllers/' . $name . '.php';
        require($file);
        //PRINT_R($file);
        $controller = new $name();
        //PRINT_R($controller);
        return $controller;


    }

}

?>